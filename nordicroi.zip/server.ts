import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK with telemetry header
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
}

// In-Memory Database for Leads and Interaction History
interface Lead {
  id: string;
  name: string;
  phone: string;
  productName: string;
  price: number;
  eventType: "abandoned_checkout" | "card_declined" | "boleto_expired";
  reason: string;
  priority: "alto" | "medio" | "baixo";
  behaviorHistory: string;
  whatsappMessage: string;
  delayEnvio: string;
  gatilhoPsicologico: string;
  status: "aguardando" | "negociando" | "convertido" | "perdido";
  interactionsCount: number;
  couponOffered: boolean;
  couponCode?: string;
  chatHistory: {
    sender: "client" | "architect";
    message: string;
    timestamp: string;
  }[];
  createdAt: string;
}

let leadsDatabase: Lead[] = [];

// Activity logs feed
interface ActivityLog {
  id: string;
  timestamp: string;
  type: "webhook_received" | "chat_message" | "sale_recovered" | "sale_lost";
  message: string;
  leadName: string;
  leadId: string;
}

let activityLogs: ActivityLog[] = [];

// Helper to check and fallback when Gemini is unavailable
function getMockAIService(
  name: string,
  productName: string,
  price: number,
  eventType: string,
  reason: string,
  behavior: string
) {
  let msg = "Oi, vi que deu um erro no seu pagamento aqui, quer que eu te ajude a liberar o acesso agora?";
  let delay = "5";
  let trigger = "Empatia Técnica";
  let priority: "alto" | "medio" | "baixo" = "medio";

  if (eventType === "card_declined") {
    msg = `Oi ${name.split(" ")[0]}, vi que deu um pequeno impasse na hora de aprovar seu cartão no checkout do ${productName}. Geralmente é só o banco bloqueando por segurança de compra online. Quer que eu te envie um link alternativo Pix ou gere um boleto rápido pra você não perder o acesso agora?`;
    trigger = "Empatia de suporte rápido";
    delay = "3";
    priority = "alto";
  } else if (eventType === "abandoned_checkout") {
    msg = `Oi ${name.split(" ")[0]}, tudo bem? Notei que você iniciou sua inscrição no ${productName}, mas acabou parando no meio do caminho. Faltou alguma informação importante ou deu algum erro na tela pra você finalizar? Me conta aqui que te ajudo a liberar o acesso agora!`;
    trigger = "Apoio humanizado & Escassez sutil";
    delay = "10";
    priority = "medio";
  } else if (eventType === "boleto_expired") {
    msg = `Oi ${name.split(" ")[0]}, o boleto que você gerou pro ${productName} acabou de vencer. Mas calma, eu consigo segurar sua vaga promocional se você quiser pagar no Pix rapidinho agora. Quer que eu mande a chave cópia e cola?`;
    trigger = "Escassez de vaga promocional por tempo determinado";
    delay = "20";
    priority = "baixo";
  }

  return {
    mensagem_whatsapp: msg,
    delay_envio: delay,
    gatilho_psicologico: trigger,
    status_prioridade: priority
  };
}

// API Routes

// Get all leads
app.get("/api/leads", (req, res) => {
  res.json({ leads: leadsDatabase, logs: activityLogs });
});

// Reset database
app.post("/api/leads/reset", (req, res) => {
  leadsDatabase = [];
  activityLogs = [
    {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: "webhook_received",
      message: "Banco de dados e histórico de recuperação limpos para um novo ciclo de venda.",
      leadName: "Sistema",
      leadId: ""
    }
  ];

  res.json({ message: "Database reset complete", leads: leadsDatabase, logs: activityLogs });
});

// Set lead status directly (mock conversion or lost)
app.post("/api/leads/status", (req, res) => {
  const { leadId, status } = req.body;
  const lead = leadsDatabase.find(l => l.id === leadId);
  if (!lead) {
    return res.status(404).json({ error: "Lead não encontrado" });
  }

  lead.status = status;

  const logMessage = status === "convertido"
    ? `Venda RECUPERADA via WhatsApp! Produto: ${lead.productName} por R$ ${lead.couponOffered ? (lead.price * 0.9).toFixed(2) : lead.price.toFixed(2)} (${lead.couponOffered ? 'com cupom de 10%' : 'valor integral'}).`
    : `Ticket encerrado como Perdido para o lead ${lead.name}.`;

  const newLog: ActivityLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    type: status === "convertido" ? "sale_recovered" : "sale_lost",
    message: logMessage,
    leadName: lead.name,
    leadId: lead.id
  };

  activityLogs.unshift(newLog);
  res.json({ success: true, lead, logs: activityLogs });
});

// Process dynamic webhook simulation
app.post("/api/leads/webhook", async (req, res) => {
  const { name, phone, productName, price, eventType, reason, behaviorHistory } = req.body;

  if (!name || !phone || !productName || !price || !eventType) {
    return res.status(400).json({ error: "Parâmetros obrigatórios ausentes" });
  }

  let recoveryPlan;

  if (ai) {
    try {
      const prompt = `
        Analise o seguinte contexto de falha de checkout de um Micro-SaaS e gere a mensagem ideal de recuperação profissional para WhatsApp.
        
        DADOS DO LEAD:
        - Nome: ${name}
        - Telefone: ${phone}
        - Nome do Produto Micro-SaaS: ${productName}
        - Valor do Produto: R$ ${price}
        - Tipo do Evento: ${eventType} (abandoned_checkout = abandono de carrinho, card_declined = cartão de crédito recusado, boleto_expired = boleto vencido)
        - Motivo do erro ou falha no checkout: ${reason || 'Não especificado'}
        - Histórico de comportamento na plataforma de vendas: ${behaviorHistory || 'Primeira vez acessando o checkout'}
        
        INSTRUÇÕES DE CONVERSÃO & TONE OF VOICE:
        1. Análise do Contexto: Entenda o motivo de falha e o comportamento do cliente. Crie uma mensagem curta, direta e altamente humanizada.
        2. Gatilhos Psicológicos: Use escassez real (vagas limitadas, expiração iminente da oferta) e empatia técnica (compreensão do problema com o cartão ou faturamento sem ser invasivo).
        3. Tom de Voz: Profissional, amigável, sutilmente sagaz (witty) e focado em resolver a dor do cliente imediatamente.
        4. Evite saudações engessadas ou robóticas como "Olá, sou o assistente virtual do SaaS X...".
        5. Inicie com abordagens diretas e convidativas, como: "Oi, vi que deu um erro no seu pagamento aqui, quer que eu te ajude a liberar o acesso agora?" ou semelhantes e adaptadas ao nome e problema exato.
        6. Restrição de emojis: Use no MÁXIMO 1 emoji em toda a mensagem para manter o aspecto premium elegante.
        
        INSTRUÇÕES DE FORMATAÇÃO DO JSON:
        Retorne um JSON contendo os seguintes campos exatamente:
        - "mensagem_whatsapp": A mensagem completa de primeiro contato contendo até 3-4 frases, com quebras de linha amigáveis, contendo no máximo 1 emoji.
        - "delay_envio": O atraso ideal recomendado em minutos (uma string que represente o número, ex: "5", "10", "15") com base na criticidade (falhas de cartão devem ser recuperadas super rápido "2" a "5" min. Abandonos em "10" a "15" min. Boletos vencidos em "30" a "60" min).
        - "gatilho_psicologico": Nome corporativo elegante do gatilho principal empregado (ex: "Empatia de Integração Tecnológica", "Escassez por Sincronia Temporal").
        - "status_prioridade": String "alto", "medio" ou "baixo" baseada nas chances de fechamento iminente (frequência de uso, erro imediato de cartão são Alto. Desinteresse súbito é Médio/Baixo).
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              mensagem_whatsapp: { type: Type.STRING },
              delay_envio: { type: Type.STRING },
              gatilho_psicologico: { type: Type.STRING },
              status_prioridade: { type: Type.STRING }
            },
            required: ["mensagem_whatsapp", "delay_envio", "gatilho_psicologico", "status_prioridade"]
          }
        }
      });

      const resultText = response.text || "";
      const parsedData = JSON.parse(resultText);
      recoveryPlan = {
        mensagem_whatsapp: parsedData.mensagem_whatsapp,
        delay_envio: parsedData.delay_envio,
        gatilho_psicologico: parsedData.gatilho_psicologico,
        status_prioridade: parsedData.status_prioridade === "alto" || parsedData.status_prioridade === "medio" || parsedData.status_prioridade === "baixo" ? parsedData.status_prioridade : "medio"
      };

    } catch (error) {
      console.error("Gemini Webhook generation error:", error);
      // Fallback
      recoveryPlan = getMockAIService(name, productName, price, eventType, reason || "", behaviorHistory || "");
    }
  } else {
    // Fallback
    recoveryPlan = getMockAIService(name, productName, price, eventType, reason || "", behaviorHistory || "");
  }

  // Save the new Lead in the database
  const leadId = `lead-${Date.now()}`;
  const newLead: Lead = {
    id: leadId,
    name,
    phone,
    productName,
    price: Number(price),
    eventType,
    reason: reason || "Não especificado",
    behaviorHistory: behaviorHistory || "Nenhum histórico reportado",
    whatsappMessage: recoveryPlan.mensagem_whatsapp,
    delayEnvio: recoveryPlan.delay_envio,
    gatilhoPsicologico: recoveryPlan.gatilho_psicologico,
    priority: recoveryPlan.status_prioridade as "alto" | "medio" | "baixo",
    status: "aguardando",
    interactionsCount: 0,
    couponOffered: false,
    chatHistory: [
      {
        sender: "architect",
        message: recoveryPlan.mensagem_whatsapp,
        timestamp: new Date().toISOString()
      }
    ],
    createdAt: new Date().toISOString()
  };

  leadsDatabase.unshift(newLead);

  const newLog: ActivityLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    type: "webhook_received",
    message: `Novo Webhook de checkout detectado (${eventType}). Lead criado: ${name} (${productName}) - Prioridade: ${recoveryPlan.status_prioridade.toUpperCase()}`,
    leadName: name,
    leadId: leadId
  };

  activityLogs.unshift(newLog);

  res.json({ success: true, lead: newLead, logs: activityLogs });
});

// Chat simulation route using Gemini
app.post("/api/leads/chat", async (req, res) => {
  const { leadId, clientMessage } = req.body;

  if (!leadId || !clientMessage) {
    return res.status(400).json({ error: "leadId e clientMessage são obrigatórios" });
  }

  const lead = leadsDatabase.find(l => l.id === leadId);
  if (!lead) {
    return res.status(404).json({ error: "Lead não encontrado" });
  }

  // Update lead with client message
  lead.chatHistory.push({
    sender: "client",
    message: clientMessage,
    timestamp: new Date().toISOString()
  });

  // Increment customer interaction count
  lead.interactionsCount += 1;
  lead.status = "negociando";

  // Create log of chat message
  activityLogs.unshift({
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    type: "chat_message",
    message: `Resposta do cliente ${lead.name}: "${clientMessage.substring(0, 45)}${clientMessage.length > 45 ? '...' : ''}"`,
    leadName: lead.name,
    leadId: lead.id
  });

  let architectReply = "";
  let priority = lead.priority;
  let statusUpdate: "aguardando" | "negociando" | "convertido" | "perdido" = "negociando";
  let promptTriggeredCode = false;

  // Rule Verification:
  // "Se o cliente disser que está caro, você tem autorização (via lógica) para oferecer um cupom de 10% de desconto gerado na hora, mas apenas na terceira interação (interactionsCount >= 2 ou 3)."
  // Let's analyze if the client is complaining about price OR saying "está caro" / "desconto" / "preço"
  const isComplainingAboutPrice = /caro|preço|preco|desconto|abaixar|valor|pobre|dinheiro|condição|condicao|parcela/i.test(clientMessage);
  
  // Checking if coupon should be allowed
  // Let's decide: third client turn is interactionsCount >= 2 (1st message was the automated WhatsApp notification setup, 2nd message completed 1st client round, etc)
  // Let's make it easy to trigger: interactionsCount >= 2 (which represents the 3rd total interaction: 1. automated, 2. user reply, 3. architect response, 4. user pricing objection)
  // Or simply count lead.interactionsCount (where customer reply count is at least 2 or 3, let's allow it in a realistic dynamic way!)
  const isThirdInteraction = lead.interactionsCount >= 2; 
  
  let offerCoupon = false;
  if (isComplainingAboutPrice && isThirdInteraction && !lead.couponOffered) {
    offerCoupon = true;
    lead.couponOffered = true;
    lead.couponCode = `RECOV10-${Math.floor(1000 + Math.random() * 9000)}`;
  }

  if (ai) {
    try {
      const chatHistoryFormatted = lead.chatHistory.map(turn => 
        `${turn.sender === "client" ? "Cliente: " : "Recuperador (Você): "}${turn.message}`
      ).join("\n");

      const prompt = `
        Você é o "NordicROI", um agente de IA de conversão elite focado em fechar vendas de Micro-SaaS.
        Você está lidando com o lead ${lead.name} no WhatsApp sobre o produto ${lead.productName} que custa R$ ${lead.price}.
        
        DADOS DA FALHA:
        - Motivo da falha original: ${lead.reason}
        - Comportamento: ${lead.behaviorHistory}
        - Contagem atual de interações do cliente: ${lead.interactionsCount}
        
        HISTÓRICO DA CONVERSA:
        ${chatHistoryFormatted}
        
        REGRA SECRETA DE CONTROLE:
        - O cliente acaba de enviar a seguinte mensagem: "${clientMessage}"
        - O cliente reclama do preço/valor ou pede desconto? ${isComplainingAboutPrice ? 'Sim' : 'Não'}
        - É a terceira interação técnica ou superior? Status: ${isThirdInteraction ? 'PERMITIDO' : 'NEGADO'}
        - Cupom de 10% de desconto gerado e permitido agora? ${offerCoupon ? 'SIM (Código Gerado: ' + lead.couponCode + ')' : 'NÃO/Ainda Não'}
        
        INSTRUÇÕES PARA RESPONDER:
        1. Se "Cupom de 10% de desconto gerado e permitido agora" for SIM, você DEVE oferecer empatia à objeção financeira e disponibilizar o cupom de desconto real de 10% com o código exato: ${lead.couponCode} (que reduz o valor de R$ ${lead.price} para R$ ${(lead.price * 0.9).toFixed(2)}). Enfatize que é uma autorização exclusiva do sistema feita individualmente pra ele e que expira nos próximos 15 minutos!
        2. Se o cliente reclamar do preço mas NÃO for a terceira interação ainda, contorne a objeção agregando valor, destacando o ROI do SaaS ou explicando os bônus inclusos. NÃO ofereça desconto ainda! Incentive ele a experimentar ou tirar dúvidas.
        3. Se o cliente disser que quer pagar agora, ou pedir o link de pagamento, forneça uma resposta extremamente rápida e mande simular um encerramento positivo.
        4. O tom deve ser sutilmente wits/engraçado, muito persuasivo, premium e amigável.
        5. Lembre-se: Use no máximo 1 emoji em toda a resposta para manter o tom de elite.
        
        Retorne um JSON com o seguinte formato exato:
        {
          "resposta_whatsapp": "Texto da resposta contendo até no máximo 3-4 frases curtas e quebras de linha amigáveis, com no máximo 1 emoji",
          "gatilho_psicologico": "Nome do gatilho aplicado na resposta (ex: Concessão Exclusiva, Demonstração de ROI, Empatia Pessoal)"
        }
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              resposta_whatsapp: { type: Type.STRING },
              gatilho_psicologico: { type: Type.STRING }
            },
            required: ["resposta_whatsapp", "gatilho_psicologico"]
          }
        }
      });

      const parsed = JSON.parse(response.text || "{}");
      architectReply = parsed.resposta_whatsapp;
      lead.gatilhoPsicologico = parsed.gatilho_psicologico || lead.gatilhoPsicologico;

    } catch (e) {
      console.error("Gemini Chat generation error:", e);
      // Fallback response inside try-catch
      promptTriggeredCode = true;
    }
  } else {
    promptTriggeredCode = true;
  }

  // Fallback Chat generator if Gemini is missing or failed
  if (promptTriggeredCode) {
    if (offerCoupon) {
      architectReply = `Nossa, entendo perfeitamente, o mês está apertado pra todo mundo. 😅 Olha, consegui ver aqui com a diretoria do ${lead.productName} e me autorizaram a ativar o cupom exclusivo de 10%: *${lead.couponCode}*. O valor cai de R$ ${lead.price.toFixed(2)} para R$ ${(lead.price * 0.9).toFixed(2)}. Posso te mandar o link de checkout atualizado?`;
      lead.gatilhoPsicologico = "Concessão financeira excepcional personalizada";
    } else if (isComplainingAboutPrice) {
      architectReply = `Eu te entendo! O valor do ${lead.productName} parece alto à primeira vista, mas ele se paga logo nos primeiros dias otimizando seus fluxos de trabalho. O que acha de fazermos um teste guiado de 15 minutos sem compromisso pra você ver o resultado valer a pena?`;
      lead.gatilhoPsicologico = "Demonstração prática de ROI";
    } else if (/pix|boleto|cartao|cartão|pagar|link/i.test(clientMessage)) {
      architectReply = `Maravilha! Gerando seu link de pagamento prioritário aqui protegido e com liberação imediata. É só me avisar assim que fizer pra eu rodar a ativação aqui do plano. Quer o link agora?`;
      lead.gatilhoPsicologico = "Aceleração de Fluxo de Checkout";
    } else {
      architectReply = `Entendi seu ponto. No caso do ${lead.productName}, preparamos justamente essa infraestrutura pra evitar esse tipo de erro técnico no faturamento. Quer que eu verifique seu cadastro de e-mail pra gente ver se está tudo correto para o login?`;
      lead.gatilhoPsicologico = "Empatia de suporte técnico";
    }
  }

  // Save response to history
  lead.chatHistory.push({
    sender: "architect",
    message: architectReply,
    timestamp: new Date().toISOString()
  });

  // Log active chat reply
  activityLogs.unshift({
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    type: "chat_message",
    message: `Resposta da IA Recuperadora enviada para ${lead.name}: "${architectReply.substring(0, 45)}..."`,
    leadName: lead.name,
    leadId: lead.id
  });

  res.json({
    success: true,
    reply: architectReply,
    lead,
    logs: activityLogs
  });
});

// Serve Frontend

// Vite middleware for development
if (process.env.NODE_ENV !== "production") {
  (async () => {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    
    // In dev mode, let Vite handle all remaining requests
    app.get("*", (req, res, next) => {
      // API routes should not be matched by Vite
      if (req.path.startsWith("/api")) {
        return next();
      }
      res.sendFile(path.join(process.cwd(), "index.html"));
    });
  })();
} else {
  // Serve static assets in production mode
  const distPath = path.join(process.cwd(), "dist");
  app.use(express.static(distPath));
  
  app.get("*", (req, res) => {
    if (req.path.startsWith("/api")) {
      return res.status(404).json({ error: "APIs not found" });
    }
    res.sendFile(path.join(distPath, "index.html"));
  });
}

// Start Server
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server fully operational on http://localhost:${PORT}`);
});
