import React, { useState, useEffect, useRef } from "react";
import {
  MessageSquare,
  Plus,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  XCircle,
  TrendingUp,
  Send,
  Sparkles,
  Clock,
  Coins,
  Activity,
  ChevronRight,
  User,
  Phone,
  ShoppingBag,
  Eye,
  HelpCircle,
  Ticket,
  Percent,
  LogOut
} from "lucide-react";
import { Lead, ActivityLog, EventType, PriorityLevel, LeadStatus } from "./types";
import LandingPage from "./components/LandingPage";
const logoImgUrl = "/nordicroi-logo.png";

export default function App() {
  const [user, setUser] = useState<{ name: string; email: string; avatar: string } | null>(() => {
    const saved = localStorage.getItem("nordicroi_user");
    return saved ? JSON.parse(saved) : null;
  });

  const handleLoginSuccess = (loginUser: { name: string; email: string; avatar: string }) => {
    localStorage.setItem("nordicroi_user", JSON.stringify(loginUser));
    setUser(loginUser);
  };

  const handleLogout = () => {
    if (window.confirm("Deseja sair da sua conta NordicROI?")) {
      localStorage.removeItem("nordicroi_user");
      setUser(null);
    }
  };

  const [leads, setLeads] = useState<Lead[]>([]);
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [selectedLeadId, setSelectedLeadId] = useState<string>("");
  const [loadingLeads, setLoadingLeads] = useState<boolean>(true);
  
  // Webhook Simulation Form State
  const [newLeadName, setNewLeadName] = useState<string>("Gabriel Oliveira");
  const [newLeadPhone, setNewLeadPhone] = useState<string>("+55 (11) 97432-8899");
  const [newLeadProduct, setNewLeadProduct] = useState<string>("InboundGrow AI");
  const [newLeadPrice, setNewLeadPrice] = useState<number>(147.00);
  const [newLeadEvent, setNewLeadEvent] = useState<EventType>("card_declined");
  const [newLeadReason, setNewLeadReason] = useState<string>("Transação recusada pela operadora (Possível fraude suspeita)");
  const [newLeadBehavior, setNewLeadBehavior] = useState<string>("Visitou a página de checkout 3 vezes nos últimos 15 minutos. Gerou um clone de checkout anterior e desistiu.");
  const [submittingWebhook, setSubmittingWebhook] = useState<boolean>(false);

  // Chat Simulation State
  const [clientMessage, setClientMessage] = useState<string>("");
  const [sendingMessage, setSendingMessage] = useState<boolean>(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Selected Lead Information helpers
  const selectedLead = leads.find(l => l.id === selectedLeadId);

  // Fetch initial data
  const fetchData = async () => {
    try {
      setLoadingLeads(true);
      const res = await fetch("/api/leads");
      if (res.ok) {
        const data = await res.json();
        setLeads(data.leads || []);
        setLogs(data.logs || []);
        if (data.leads && data.leads.length > 0 && !selectedLeadId) {
          setSelectedLeadId(data.leads[0].id);
        }
      }
    } catch (error) {
      console.error("Error loading leads:", error);
    } finally {
      setLoadingLeads(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Scroll to bottom of chat when history changes
  useEffect(() => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [selectedLead?.chatHistory]);

  // Handler to Reset Mock database
  const handleReset = async () => {
    if (window.confirm("Deseja restaurar os leads de simulação padrão?")) {
      try {
        const res = await fetch("/api/leads/reset", { method: "POST" });
        if (res.ok) {
          const data = await res.json();
          setLeads(data.leads);
          setLogs(data.logs);
          if (data.leads.length > 0) {
            setSelectedLeadId(data.leads[0].id);
          }
        }
      } catch (error) {
        console.error("Failed to reset database", error);
      }
    }
  };

  // Handler to submit Webhook
  const handleSimulateWebhook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLeadName || !newLeadPhone || !newLeadProduct || !newLeadPrice) {
      alert("Por favor, preencha todos os campos obrigatórios");
      return;
    }

    try {
      setSubmittingWebhook(true);
      const res = await fetch("/api/leads/webhook", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newLeadName,
          phone: newLeadPhone,
          productName: newLeadProduct,
          price: Number(newLeadPrice),
          eventType: newLeadEvent,
          reason: newLeadReason,
          behaviorHistory: newLeadBehavior
        })
      });

      if (res.ok) {
        const data = await res.json();
        setLeads(data.leads || []);
        setLogs(data.logs || []);
        if (data.lead) {
          setSelectedLeadId(data.lead.id);
        }
        // Reset webhook form defaults
        setNewLeadName("Lucas Ferreira");
        setNewLeadPhone("+55 (19) 98111-2233");
        setNewLeadReason("Abandono na etapa final de Pix gerado.");
        setNewLeadBehavior("Visualizou depoimentos e FAQ por 6 minutos antes de carregar o checkout.");
      }
    } catch (err) {
      console.error("Webhook error:", err);
    } finally {
      setSubmittingWebhook(false);
    }
  };

  // Handler to send Client message (chat simulation)
  const handleSendClientMessage = async (msgText?: string) => {
    const textToSend = msgText || clientMessage;
    if (!textToSend.trim() || !selectedLeadId) return;

    try {
      setSendingMessage(true);
      if (!msgText) setClientMessage("");

      const res = await fetch("/api/leads/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          leadId: selectedLeadId,
          clientMessage: textToSend
        })
      });

      if (res.ok) {
        const data = await res.json();
        // Update local state with updated lead info and logs
        setLeads(prevLeads => prevLeads.map(l => l.id === data.lead.id ? data.lead : l));
        setLogs(data.logs);
      }
    } catch (err) {
      console.error("Chat message simulation error:", err);
    } finally {
      setSendingMessage(false);
    }
  };

  // Handler to update status (Convert or Lost)
  const handleUpdateStatus = async (status: "convertido" | "perdido") => {
    if (!selectedLeadId) return;

    try {
      const res = await fetch("/api/leads/status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          leadId: selectedLeadId,
          status: status
        })
      });

      if (res.ok) {
        const data = await res.json();
        setLeads(prevLeads => prevLeads.map(l => l.id === data.lead.id ? data.lead : l));
        setLogs(data.logs);
      }
    } catch (err) {
      console.error("Status update error:", err);
    }
  };

  // Select realistic presets pro webhook
  const applyPreset = (presetType: "auth" | "metrics" | "analytics") => {
    if (presetType === "auth") {
      setNewLeadName("Amanda Pinheiro");
      setNewLeadPhone("+55 (31) 98834-1100");
      setNewLeadProduct("AuthGuard Pro");
      setNewLeadPrice(49.00);
      setNewLeadEvent("abandoned_checkout");
      setNewLeadReason("Preencheu o e-mail mas hesitou por 10 minutos na tela de digitar cartão");
      setNewLeadBehavior("Baixou o e-book gratuito há uma semana, abriu 2 e-mails de nutrição, mas clicou direto do e-mail promocional.");
    } else if (presetType === "metrics") {
      setNewLeadName("Rodolfo Mendes");
      setNewLeadPhone("+55 (81) 99122-3774");
      setNewLeadProduct("CloudPulse Metrics");
      setNewLeadPrice(297.00);
      setNewLeadEvent("card_declined");
      setNewLeadReason("Recusa de transação com erro genérico 51 (Insuficiente)");
      setNewLeadBehavior("Iniciou teste gratuito de 7 dias que expirou ontem. Tentou cadastrar o cartão corporativo hoje duas vezes consecutivas.");
    } else if (presetType === "analytics") {
      setNewLeadName("Carla Diaz");
      setNewLeadPhone("+55 (41) 97651-4455");
      setNewLeadProduct("SocialStats AI");
      setNewLeadPrice(129.00);
      setNewLeadEvent("boleto_expired");
      setNewLeadReason("Vencimento do Boleto registrado às 23:59 horas de ontem");
      setNewLeadBehavior("Criou uma conta sandbox na plataforma e configurou uma integração de Instagram. Não abriu as notificações de lembrete por e-mail.");
    }
  };

  const handleSelectErrorPreset = (type: "fraude" | "saldo" | "boleto" | "abandono") => {
    if (type === "fraude") {
      setNewLeadName("Carlos Eduardo");
      setNewLeadPhone("+55 (11) 98221-5500");
      setNewLeadProduct("InboundGrow AI");
      setNewLeadPrice(147.00);
      setNewLeadEvent("card_declined");
      setNewLeadReason("Transação recusada pela operadora (Possível fraude suspeita)");
      setNewLeadBehavior("Visitou a página de checkout 3 vezes nos últimos 15 minutos. Tentativas sucessivas com cartões de titulares diferentes.");
    } else if (type === "saldo") {
      setNewLeadName("Sarah Martins");
      setNewLeadPhone("+55 (21) 97116-3434");
      setNewLeadProduct("CloudPulse Metrics");
      setNewLeadPrice(297.00);
      setNewLeadEvent("card_declined");
      setNewLeadReason("Recusa do emissor: Saldo insuficiente na conta/limite");
      setNewLeadBehavior("Já usa a conta sandbox há 2 meses mas seu limite corporativo excedeu na tentativa de fazer o upgrade.");
    } else if (type === "boleto") {
      setNewLeadName("Vitor Rezende");
      setNewLeadPhone("+55 (31) 99120-7766");
      setNewLeadProduct("SEOEngine AI");
      setNewLeadPrice(349.00);
      setNewLeadEvent("boleto_expired");
      setNewLeadReason("Boleto vencido reportado no checkout do gateway");
      setNewLeadBehavior("Preencheu os dados, emitiu o boleto no sábado mas esqueceu de pagar no prazo de vencimento na segunda-feira.");
    } else if (type === "abandono") {
      setNewLeadName("Amanda Pinheiro");
      setNewLeadPhone("+55 (11) 98834-1100");
      setNewLeadProduct("AuthGuard Pro");
      setNewLeadPrice(49.00);
      setNewLeadEvent("abandoned_checkout");
      setNewLeadReason("Abandono Manual: Preencheu dados iniciais mas hesitou na tela do cartão");
      setNewLeadBehavior("Clicou no anúncio promocional do Instagram, preencheu os contatos, mas saiu do checkout sem digitar o CPF.");
    }
  };

  // Calculation metrics
  const totalLeads = leads.length;
  const recoveredSalesCount = leads.filter(l => l.status === "convertido").length;
  const lostSalesCount = leads.filter(l => l.status === "perdido").length;
  const totalValueRecovered = leads
    .filter(l => l.status === "convertido")
    .reduce((acc, current) => {
      const pricePaid = current.couponOffered ? (current.price * 0.9) : current.price;
      return acc + pricePaid;
    }, 0);

  const recoveryRate = totalLeads > 0 
    ? Math.round(((recoveredSalesCount + lostSalesCount) > 0 ? (recoveredSalesCount / (recoveredSalesCount + lostSalesCount)) * 100 : 0))
    : 0;

  if (!user) {
    return <LandingPage onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-indigo-500 selection:text-white" id="main-root-container">
      {/* Premium Header */}
      <header className="border-b border-slate-900 bg-slate-950/80 backdrop-blur-md sticky top-0 z-50 py-3.5 px-6 flex items-center justify-between" id="header-bar">
        <div className="flex items-center space-x-3" id="brand-logo-container">
          <div className="w-10 h-10 rounded-xl overflow-hidden border border-slate-800 bg-slate-950 flex items-center justify-center shadow-lg shadow-indigo-500/10" id="brand-badge">
            <img
              src={logoImgUrl}
              alt="NordicROI Logo"
              className="w-full h-full object-cover select-none pointer-events-none"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <h1 className="text-lg font-semibold tracking-tight font-sans text-white flex items-center" id="brand-title">
              NordicROI <span className="ml-2 text-[10px] text-emerald-400 font-mono bg-emerald-950 border border-emerald-900 px-1.5 py-0.5 rounded uppercase">V2.4 Powered</span>
            </h1>
            <p className="text-xs text-slate-400" id="brand-subtitle">Automated WhatsApp Conversions Engine for Micro-SaaS</p>
          </div>
        </div>

        <div className="flex items-center space-x-3" id="actions-header">
          <button
            onClick={fetchData}
            disabled={loadingLeads}
            className="p-2 text-slate-400 hover:text-slate-100 hover:bg-slate-900 border border-slate-900 rounded-lg transition-colors flex items-center justify-center"
            title="Sincronizar Banco"
            id="sync-btn"
          >
            <RefreshCw className={`w-4 h-4 ${loadingLeads ? "animate-spin" : ""}`} />
          </button>
          
          <button
            className="text-xs px-3 py-1.5 font-medium border border-slate-800 text-slate-400 hover:text-rose-400 hover:bg-rose-950/15 rounded-lg transition-colors flex items-center space-x-2"
            onClick={handleReset}
            id="reset-db-btn"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Resetar Leads</span>
          </button>

          <div className="h-6 w-[1px] bg-slate-800/80 mx-1" />

          {/* User Profile Badge */}
          <div className="flex items-center space-x-2 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg" id="user-profile-badge">
            <img src={user.avatar} alt="User Avatar" className="w-5 h-5 rounded-full select-none pointer-events-none" />
            <span className="text-xs font-semibold text-slate-300 hidden md:inline">{user.name}</span>
          </div>

          {/* Logout Button */}
          <button
            onClick={handleLogout}
            className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-950/15 border border-slate-800 hover:border-rose-900/40 rounded-lg transition-colors flex items-center justify-center cursor-pointer"
            title="Sair da Conta"
            id="logout-btn"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Statistics Metric Bar */}
      <section className="bg-slate-950 border-b border-slate-900/60 py-4 px-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" id="metrics-panel">
        <div className="bg-slate-900/40 border border-slate-900 p-4 rounded-xl flex items-center justify-between" id="metric-recovered-revenue">
          <div>
            <span className="text-[10px] uppercase tracking-wider text-slate-500 font-medium">Recuperado</span>
            <p className="text-xl font-bold font-mono text-emerald-400 mt-0.5">
              R$ {totalValueRecovered.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </p>
          </div>
          <div className="w-9 h-9 rounded-lg bg-emerald-950/40 border border-emerald-900/30 flex items-center justify-center text-emerald-400">
            <Coins className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900/40 border border-slate-900 p-4 rounded-xl flex items-center justify-between" id="metric-leads-count">
          <div>
            <span className="text-[10px] uppercase tracking-wider text-slate-500 font-medium">Total de Leads</span>
            <p className="text-xl font-bold font-mono text-white mt-0.5">{totalLeads}</p>
          </div>
          <div className="w-9 h-9 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center text-slate-400">
            <User className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900/40 border border-slate-900 p-4 rounded-xl flex items-center justify-between" id="metric-rate">
          <div>
            <span className="text-[10px] uppercase tracking-wider text-slate-500 font-medium font-mono">Taxa de Sucesso</span>
            <p className="text-xl font-bold font-mono text-indigo-400 mt-0.5">{recoveryRate}%</p>
          </div>
          <div className="w-9 h-9 rounded-lg bg-indigo-950/40 border border-indigo-900/30 flex items-center justify-center text-indigo-400">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-900/40 border border-slate-900 p-4 rounded-xl flex items-center justify-between" id="metric-conversion-badges">
          <div>
            <span className="text-[10px] uppercase tracking-wider text-slate-500 font-medium">Resultados Fechados</span>
            <div className="flex items-center space-x-3 mt-1.5 text-xs text-slate-300">
              <span className="flex items-center">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 mr-1" />
                <span className="font-mono text-emerald-400 font-semibold">{recoveredSalesCount}</span>
              </span>
              <span className="flex items-center">
                <XCircle className="w-3.5 h-3.5 text-rose-500 mr-1" />
                <span className="font-mono text-rose-400 font-semibold">{lostSalesCount}</span>
              </span>
            </div>
          </div>
          <div className="w-9 h-9 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center text-indigo-400">
            <Percent className="w-5 h-5" />
          </div>
        </div>
      </section>

      {/* Main Container Layout */}
      <div className="flex-1 grid grid-cols-1 xl:grid-cols-12 gap-5 p-6" id="applet-grid-system">
        
        {/* Left Column (Leads + Webhook Simulation) */}
        <section className="xl:col-span-4 flex flex-col space-y-5" id="left-sidebar-controls">
          
          {/* Simulate Hook Card */}
          <div className="bg-slate-900/60 border border-slate-900 rounded-2xl overflow-hidden shadow-xl" id="hook-form-card">
            <div className="bg-gradient-to-r from-slate-900 to-slate-900/40 px-5 py-4 border-b border-slate-900 flex justify-between items-center" id="hook-form-title-bar">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center">
                <Plus className="w-4 h-4 text-emerald-400 mr-2" />
                Webhook Simulador Kiwify / Hotmart
              </span>
              <span className="text-[10px] font-mono text-indigo-400 bg-indigo-950 border border-indigo-900/60 px-2 py-0.5 rounded-full select-none">
                Auto-recover
              </span>
            </div>

            <div className="p-5" id="form-container">
              {/* Presets Button Fast Fill */}
              <div className="mb-4" id="presets-selection">
                <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block mb-2">Preencher com Cenários de Teste:</span>
                <div className="grid grid-cols-3 gap-1.5" id="presets-grid-row">
                  <button
                    type="button"
                    onClick={() => applyPreset("auth")}
                    className="text-[10px] bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 px-2 py-1.5 rounded-lg font-medium transition-all text-left truncate"
                  >
                    🔐 AuthGuard Pro
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPreset("metrics")}
                    className="text-[10px] bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 px-2 py-1.5 rounded-lg font-medium transition-all text-left truncate"
                  >
                    📊 CloudPulse App
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPreset("analytics")}
                    className="text-[10px] bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 px-2 py-1.5 rounded-lg font-medium transition-all text-left truncate"
                  >
                    📈 SocialStats
                  </button>
                </div>
              </div>

              <form onSubmit={handleSimulateWebhook} className="space-y-3.5" id="simulation-actual-form">
                <div>
                  <label className="block text-[11px] uppercase tracking-wider font-semibold text-slate-400 mb-1">Nome Completo</label>
                  <input
                    type="text"
                    required
                    value={newLeadName}
                    onChange={(e) => setNewLeadName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-sans"
                    placeholder="Nome do cliente"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider font-semibold text-slate-400 mb-1">Telefone WhatsApp</label>
                    <input
                      type="text"
                      required
                      value={newLeadPhone}
                      onChange={(e) => setNewLeadPhone(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 transition-all font-mono"
                      placeholder="+55 (11) 99999-9999"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider font-semibold text-slate-400 mb-1">SaaS Produto</label>
                    <input
                      type="text"
                      required
                      value={newLeadProduct}
                      onChange={(e) => setNewLeadProduct(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500 transition-all font-sans"
                      placeholder="Nome do SaaS"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider font-semibold text-slate-400 mb-1">Valor (R$)</label>
                    <input
                      type="number"
                      required
                      value={newLeadPrice}
                      onChange={(e) => setNewLeadPrice(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500 transition-all font-mono"
                      placeholder="97.00"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider font-semibold text-slate-400 mb-1">Falha de Evento</label>
                    <select
                      value={newLeadEvent}
                      onChange={(e) => setNewLeadEvent(e.target.value as EventType)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-indigo-500 transition-all text-slate-100 cursor-pointer"
                    >
                      <option value="card_declined">Cartão Recusado</option>
                      <option value="abandoned_checkout">Carrinho Abandonado</option>
                      <option value="boleto_expired">Boleto Vencido</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider font-semibold text-slate-400 mb-1">Motivo do Erro / Gateway</label>
                  <input
                    type="text"
                    value={newLeadReason}
                    onChange={(e) => setNewLeadReason(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500 transition-all font-sans"
                    placeholder="Sem saldo, suspeita de fraude..."
                  />

                  {/* Interactive Visual Gateway Error Chart */}
                  <div className="space-y-2 mt-2.5 p-3 rounded-xl bg-slate-950/85 border border-slate-800/80" id="gateway-errors-chart-container">
                    <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
                      <span className="flex items-center">
                        <TrendingUp className="w-3 h-3 text-indigo-400 mr-1" />
                        DISTRIBUIÇÃO DE FALHAS
                      </span>
                      <span className="text-slate-500">Clique p/ Autopreencher</span>
                    </div>

                    {/* Stacked bar chart representation */}
                    <div className="h-3 w-full rounded-full overflow-hidden flex bg-slate-900 border border-slate-900/60 shadow-inner" id="gateway-chart-bar-visual">
                      <div 
                        className="bg-rose-500 hover:bg-rose-400 transition-colors cursor-pointer h-full relative group" 
                        style={{ width: "42%" }} 
                        title="Fraude Suspeita: 42% de incidência"
                        onClick={() => handleSelectErrorPreset("fraude")}
                      >
                        <div className="absolute -top-7 left-1/2 -translate-x-1/2 scale-0 group-hover:scale-100 transition-all bg-slate-900 text-white font-mono text-[9px] px-1.5 py-0.5 rounded shadow whitespace-nowrap z-10 border border-slate-800">
                          Fraude (42%)
                        </div>
                      </div>
                      <div 
                        className="bg-amber-500 hover:bg-amber-400 transition-colors cursor-pointer h-full relative group" 
                        style={{ width: "28%" }} 
                        title="Saldo Insuficiente: 28% de incidência"
                        onClick={() => handleSelectErrorPreset("saldo")}
                      >
                        <div className="absolute -top-7 left-1/2 -translate-x-1/2 scale-0 group-hover:scale-100 transition-all bg-slate-900 text-white font-mono text-[9px] px-1.5 py-0.5 rounded shadow whitespace-nowrap z-10 border border-slate-800">
                          Saldo (28%)
                        </div>
                      </div>
                      <div 
                        className="bg-blue-500 hover:bg-blue-400 transition-colors cursor-pointer h-full relative group" 
                        style={{ width: "18%" }} 
                        title="Boleto Vencido: 18% de incidência"
                        onClick={() => handleSelectErrorPreset("boleto")}
                      >
                        <div className="absolute -top-7 left-1/2 -translate-x-1/2 scale-0 group-hover:scale-100 transition-all bg-slate-900 text-white font-mono text-[9px] px-1.5 py-0.5 rounded shadow whitespace-nowrap z-10 border border-slate-800">
                          Boleto (18%)
                        </div>
                      </div>
                      <div 
                        className="bg-emerald-500 hover:bg-emerald-400 transition-colors cursor-pointer h-full relative group" 
                        style={{ width: "12%" }} 
                        title="Abandono de Checkout: 12% de incidência"
                        onClick={() => handleSelectErrorPreset("abandono")}
                      >
                        <div className="absolute -top-7 left-1/2 -translate-x-1/2 scale-0 group-hover:scale-100 transition-all bg-slate-900 text-white font-mono text-[9px] px-1.5 py-0.5 rounded shadow whitespace-nowrap z-10 border border-slate-800">
                          Abandono (12%)
                        </div>
                      </div>
                    </div>

                    {/* Detailed Interactive Legends Grid */}
                    <div className="grid grid-cols-2 gap-1.5 mt-2" id="gateway-chart-legend">
                      <button
                        type="button"
                        onClick={() => handleSelectErrorPreset("fraude")}
                        className={`flex items-center space-x-2 p-1.5 rounded-lg border text-left cursor-pointer transition-all ${
                          newLeadReason.includes("fraude") || newLeadReason.includes("operadora")
                            ? "bg-rose-950/20 border-rose-500/50 shadow-sm text-slate-100"
                            : "bg-slate-900/40 border-slate-900/80 text-slate-400 hover:border-slate-800 hover:text-slate-300"
                        }`}
                      >
                        <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="text-[10px] font-semibold leading-tight truncate">Fraude Suspeita</p>
                          <p className="text-[9px] text-rose-400 font-mono">42% • Alta Rec </p>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectErrorPreset("saldo")}
                        className={`flex items-center space-x-2 p-1.5 rounded-lg border text-left cursor-pointer transition-all ${
                          newLeadReason.includes("Saldo") || newLeadReason.includes("Recusa do emissor")
                            ? "bg-amber-950/20 border-amber-500/50 shadow-sm text-slate-100"
                            : "bg-slate-900/40 border-slate-900/80 text-slate-400 hover:border-slate-800 hover:text-slate-300"
                        }`}
                      >
                        <span className="w-2 h-2 rounded-full bg-amber-50 shrink-0 border border-amber-500 bg-amber-500" />
                        <div className="min-w-0 flex-1">
                          <p className="text-[10px] font-semibold leading-tight truncate">Saldo Insuficiente</p>
                          <p className="text-[9px] text-amber-400 font-mono">28% • Médio Rec </p>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectErrorPreset("boleto")}
                        className={`flex items-center space-x-2 p-1.5 rounded-lg border text-left cursor-pointer transition-all ${
                          newLeadReason.includes("Boleto") || newLeadReason.includes("boleto")
                            ? "bg-blue-950/20 border-blue-500/50 shadow-sm text-slate-100"
                            : "bg-slate-900/40 border-slate-900/80 text-slate-400 hover:border-slate-800 hover:text-slate-300"
                        }`}
                      >
                        <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="text-[10px] font-semibold leading-tight truncate">Boleto Vencido</p>
                          <p className="text-[9px] text-blue-400 font-mono">18% • Baixa Rec </p>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectErrorPreset("abandono")}
                        className={`flex items-center space-x-2 p-1.5 rounded-lg border text-left cursor-pointer transition-all ${
                          newLeadReason.includes("Abandono")
                            ? "bg-emerald-950/20 border-emerald-500/50 shadow-sm text-slate-100"
                            : "bg-slate-900/40 border-slate-900/80 text-slate-400 hover:border-slate-800 hover:text-slate-300"
                        }`}
                      >
                        <span className="w-2 h-2 rounded-full bg-emerald-505 bg-emerald-500 shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="text-[10px] font-semibold leading-tight truncate">Abandono Manual</p>
                          <p className="text-[9px] text-emerald-400 font-mono">12% • Médio Rec </p>
                        </div>
                      </button>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider font-semibold text-slate-400 mb-1">Comportamento Geral detectado</label>
                  <textarea
                    rows={2}
                    value={newLeadBehavior}
                    onChange={(e) => setNewLeadBehavior(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 transition-all font-sans"
                    placeholder="Histórico de visitas da página de compras ou logins prévios..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={submittingWebhook}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:bg-indigo-900 border border-indigo-700 py-2.5 rounded-lg transition-colors font-medium text-xs flex items-center justify-center space-x-2 text-white shadow-lg shadow-indigo-600/10 cursor-pointer"
                  id="submit-simulate-hook-btn"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{submittingWebhook ? "Processando com a Inteligência..." : "Processar Webhook & Gerar Mensagem"}</span>
                </button>
              </form>
            </div>
          </div>

          {/* List of Active Leads */}
          <div className="bg-slate-900/60 border border-slate-900 rounded-2xl flex-1 flex flex-col overflow-hidden min-h-[300px]" id="leads-list-wrapper">
            <div className="px-5 py-4 border-b border-slate-900 bg-slate-900/30 flex justify-between items-center" id="leads-list-header">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center">
                <Activity className="w-4 h-4 text-indigo-400 mr-2" />
                Fila de Leads Ativos ({leads.length})
              </span>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3.5 max-h-[400px] xl:max-h-none" id="leads-list-scrollable">
              {loadingLeads ? (
                <div className="flex flex-col items-center justify-center py-12 text-slate-500" id="leads-loading-state">
                  <RefreshCw className="w-8 h-8 animate-spin text-slate-600 mb-3" />
                  <p className="text-xs">Carregando fila de simulação...</p>
                </div>
              ) : leads.length === 0 ? (
                <div className="text-center py-12 text-slate-500 text-xs border border-dashed border-slate-900 rounded-xl" id="leads-empty-state">
                  Nenhum lead processado ainda. Use o simulador de webhook acima!
                </div>
              ) : (
                leads.map((lead) => {
                  const isSelected = lead.id === selectedLeadId;
                  let badgeColor = "bg-rose-950/40 text-rose-400 border-rose-900/30";
                  let badgeText = "Cartão";
                  if (lead.eventType === "abandoned_checkout") {
                    badgeColor = "bg-amber-950/40 text-amber-400 border-amber-900/30";
                    badgeText = "Carrinho";
                  } else if (lead.eventType === "boleto_expired") {
                    badgeColor = "bg-slate-950 text-slate-400 border-slate-800";
                    badgeText = "Boleto";
                  }

                  let statusText = "Aguardando";
                  let statusColor = "bg-slate-950 text-slate-400 border-slate-800";
                  if (lead.status === "convertido") {
                    statusText = "Convertido";
                    statusColor = "bg-emerald-950/50 text-emerald-400 border-emerald-900/40";
                  } else if (lead.status === "negociando") {
                    statusText = "No Chat";
                    statusColor = "bg-indigo-950/50 text-indigo-400 border-indigo-900/40 font-semibold";
                  } else if (lead.status === "perdido") {
                    statusText = "Perdido";
                    statusColor = "bg-rose-950/50 text-rose-500 border-rose-950";
                  }

                  let priorityColor = "text-rose-500";
                  if (lead.priority === "medio") priorityColor = "text-amber-500";
                  if (lead.priority === "baixo") priorityColor = "text-slate-500";

                  return (
                    <div
                      key={lead.id}
                      onClick={() => setSelectedLeadId(lead.id)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer select-none text-left ${
                        isSelected
                          ? "bg-slate-900 border-indigo-600/80 shadow-md shadow-indigo-600/5 ring-1 ring-indigo-500/20"
                          : "bg-slate-950/50 hover:bg-slate-900/40 border-slate-900/60"
                      }`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h4 className="text-xs font-semibold text-slate-200 flex items-center">
                            {lead.name}
                            <span className="ml-2 text-[8px] uppercase tracking-widest font-mono text-slate-500 font-medium">
                              {lead.phone}
                            </span>
                          </h4>
                          <span className="text-[10px] text-slate-400 font-medium font-sans mt-0.5 block">{lead.productName}</span>
                        </div>
                        <div className="flex flex-col items-end space-y-1">
                          <span className={`text-[9px] font-mono border px-2 py-0.5 rounded ${badgeColor}`}>
                            {badgeText}
                          </span>
                          <span className={`text-[8px] font-mono border px-1.5 py-0.2 rounded-full uppercase scale-90 ${statusColor}`}>
                            {statusText}
                          </span>
                        </div>
                      </div>

                      <div className="flex justify-between items-center text-[10px] text-slate-500 pt-2 border-t border-slate-900/80">
                        <span className="flex items-center">
                          <span className="w-1.5 h-1.5 rounded-full bg-slate-600 mr-1.5"></span>
                          R$ {lead.price.toFixed(2)}
                        </span>
                        <span className="flex items-center font-mono">
                          Prioridade: <span className={`ml-1 font-bold ${priorityColor} uppercase`}>{lead.priority}</span>
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </section>

        {/* Central Column (Interactive Chat simulation Sandbox) */}
        <section className="xl:col-span-5 bg-slate-900/60 border border-slate-900 rounded-3xl overflow-hidden shadow-xl flex flex-col min-h-[500px]" id="sandbox-column">
          {/* Active Title bar info */}
          <div className="px-5 py-4 border-b border-slate-900 bg-slate-900 flex justify-between items-center" id="sandbox-header">
            <div className="flex items-center space-x-3.5" id="sandbox-target-info">
              <div className="w-10 h-10 rounded-full bg-indigo-950 border border-indigo-900 flex items-center justify-center font-mono font-bold text-sm text-indigo-400">
                {selectedLead ? selectedLead.name.substring(0, 2).toUpperCase() : "WA"}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h3 className="text-sm font-semibold text-white">{selectedLead ? selectedLead.name : "Nenhum Lead Selecionado"}</h3>
                  {selectedLead && (
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="WhatsApp Ativo / Aguardando Resposta"></span>
                  )}
                </div>
                <p className="text-xs text-slate-400 font-mono">
                  {selectedLead ? `WhatsApp Connection: ${selectedLead.phone}` : "Carregue ou selecione um lead"}
                </p>
              </div>
            </div>

            {selectedLead && (
              <div className="flex items-center space-x-1" id="sandbox-status-actions">
                <button
                  onClick={() => handleUpdateStatus("convertido")}
                  disabled={selectedLead.status === "convertido"}
                  className={`text-[10px] px-2.5 py-1.5 font-semibold rounded-lg transition-colors flex items-center border cursor-pointer ${
                    selectedLead.status === "convertido"
                      ? "bg-slate-950 text-emerald-500/50 border-slate-900 cursor-not-allowed"
                      : "bg-emerald-950/20 text-emerald-400 hover:bg-emerald-900/30 border-emerald-900/50"
                  }`}
                  title="Marcar como Pago/Recuperado"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                  <span>Recuperado</span>
                </button>
                <button
                  onClick={() => handleUpdateStatus("perdido")}
                  disabled={selectedLead.status === "perdido"}
                  className={`text-[10px] px-2.5 py-1.5 font-semibold rounded-lg transition-colors flex items-center border cursor-pointer ${
                    selectedLead.status === "perdido"
                      ? "bg-slate-950 text-rose-500/50 border-slate-900 cursor-not-allowed"
                      : "bg-rose-950/20 text-rose-400 hover:bg-rose-900/30 border-rose-900/50"
                  }`}
                  title="Marcar como Descartado/Perdido"
                >
                  <XCircle className="w-3.5 h-3.5 mr-1" />
                  <span>Perdido</span>
                </button>
              </div>
            )}
          </div>

          {/* Sandbox Rules Notice (Negotiation specs) */}
          <div className="bg-indigo-950/15 border-b border-indigo-900/30 p-3.5 px-5 text-xs text-indigo-300 flex items-start space-x-3" id="rule-disclosure-badge">
            <Ticket className="w-4 h-4 text-indigo-400 mt-0.5 shrink-0" />
            <div className="space-y-0.5">
              <span className="font-semibold block text-slate-300">Regra de Conversão Financeira do NordicROI:</span>
              <p className="text-[11px] text-slate-400 leading-normal">
                Se o cliente argumentar sobre preço (objeção financeira), o sistema o contorna nas respostas iniciais. 
                <strong className="text-emerald-400 font-medium"> Apenas na 3ª interação do cliente ou posterior</strong>, o "NordicROI" tem autoridade lógica para gerar dinamicamente o voucher de 10% de desconto real!
              </p>
            </div>
          </div>

          {/* Chat message list */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-slate-950/40" id="whatsapp-message-pane">
            {!selectedLead ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-5" id="no-lead-selected-view">
                <div className="w-48 h-48 rounded-full border border-slate-800 bg-slate-950 flex items-center justify-center shadow-2xl p-1 overflow-hidden relative group" id="logo-emblem-large">
                  <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none rounded-full"></div>
                  <img
                    src={logoImgUrl}
                    alt="NordicROI Logo"
                    className="w-full h-full object-cover rounded-full select-none pointer-events-none"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="max-w-md space-y-2">
                  <h3 className="text-lg font-bold text-white tracking-tight">Painel de Recuperação NordicROI</h3>
                  <p className="text-xs text-slate-400 leading-relaxed max-w-sm mx-auto">
                    Central de decisão tática e conversão via WhatsApp. Selecione uma transação recusada na lista lateral ou simule um novo evento de checkout para iniciar as negociações automáticas.
                  </p>
                </div>
              </div>
            ) : (
              <>
                {/* Meta details regarding initial trigger */}
                <div className="text-center my-2" id="whatsapp-timeline-divider">
                  <span className="inline-block text-[10px] font-mono px-3 py-1 bg-slate-900 border border-slate-800 rounded-full text-slate-500 select-none uppercase">
                    Início do Atendimento: {selectedLead.eventType.replace("_", " ")}
                  </span>
                </div>

                {/* Automation notification delay context card */}
                <div className="bg-slate-900/35 border border-slate-900 p-4 rounded-xl space-y-2 text-xs" id="automation-context">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Automação de Checkout Original</span>
                    <span className="text-[10px] text-indigo-400 font-semibold bg-indigo-950 border border-indigo-900/40 px-2 py-0.5 rounded-full uppercase scale-90">
                      Entregue
                    </span>
                  </div>
                  <div className="space-y-1.5 text-slate-300">
                    <div>
                      <span className="text-slate-500 mr-1 font-medium font-mono text-[11px]">Gatilho Psicológico:</span> 
                      <span className="text-indigo-300 font-semibold">{selectedLead.gatilhoPsicologico}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 mr-1 font-medium font-mono text-[11px]">Atraso Recomendado:</span> 
                      <span className="text-amber-400 font-semibold font-mono">{selectedLead.delayEnvio} minutos</span>
                    </div>
                    {selectedLead.reason && (
                      <div>
                        <span className="text-slate-500 mr-1 font-medium font-mono text-[11px]">Erro reportado:</span> 
                        <span className="text-slate-400">{selectedLead.reason}</span>
                      </div>
                    )}
                    {selectedLead.behaviorHistory && (
                      <div className="bg-slate-950/60 p-2 border border-slate-900/70 rounded text-[11px] text-slate-400">
                        <span className="font-semibold text-slate-300">Inteligência Comportamental:</span> {selectedLead.behaviorHistory}
                      </div>
                    )}
                  </div>
                </div>

                {/* Primary Automated message fallback / trigger */}
                <div className="flex items-start justify-start" id="automated-seed">
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-none p-3.5 max-w-[85%] text-left relative">
                    <span className="block text-[8px] font-bold text-indigo-400 uppercase tracking-widest mb-1 select-none">Disparador Whatsapp Real-Time</span>
                    <p className="text-xs whitespace-pre-line text-slate-200 leading-relaxed font-sans">{selectedLead.whatsappMessage}</p>
                    <span className="block text-[9px] text-slate-500 text-right mt-1.5 font-mono select-none">
                      {new Date(selectedLead.createdAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })} ✓✓
                    </span>
                  </div>
                </div>

                {/* Dynamic Dialogue History */}
                {selectedLead.chatHistory && selectedLead.chatHistory.map((chat, idx) => {
                  const isClient = chat.sender === "client";
                  return (
                    <div key={`${selectedLead.id}-${idx}`} className={`flex items-start ${isClient ? "justify-end" : "justify-start"}`}>
                      <div className={`rounded-2xl p-3.5 max-w-[85%] text-left relative ${
                        isClient
                          ? "bg-indigo-600 font-sans text-white rounded-tr-none border border-indigo-500"
                          : "bg-slate-900 border border-slate-800 rounded-tl-none"
                      }`}>
                        <span className="block text-[8px] font-bold uppercase tracking-widest mb-1 select-none text-slate-300">
                          {isClient ? "Cliente" : "Recovery Architect (IA)"}
                        </span>
                        <p className={`text-xs whitespace-pre-line leading-relaxed ${isClient ? "text-slate-50 text-wrap break-words" : "text-slate-200 font-sans"}`}>
                          {chat.message}
                        </p>
                        <span className={`block text-[9px] text-right mt-1.5 font-mono select-none ${isClient ? "text-indigo-300" : "text-slate-500"}`}>
                          {new Date(chat.timestamp).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
                        </span>
                      </div>
                    </div>
                  );
                })}

                <div ref={chatBottomRef} />
              </>
            )}
          </div>

          {/* Quick Predefined Answers helper (Simulation helpers) */}
          {selectedLead && (
            <div className="bg-slate-900/40 p-3.5 border-t border-slate-900" id="quick-reply-pillboxes">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block mb-2 select-none">Respostas Rápidas de Simulação:</span>
              <div className="flex flex-wrap gap-1.5" id="simulation-reply-quick-row">
                <button
                  type="button"
                  onClick={() => handleSendClientMessage("Está muito caro para o meu orçamento atual, tem algum desconto?")}
                  disabled={sendingMessage}
                  className="text-[10px] bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 px-2.5 py-1.5 rounded-lg font-medium transition-colors cursor-pointer"
                  title="Objeção 1: 'Tá Caro' - Clientes alegam falta de verba"
                >
                  💰 "Está muito caro, tem desconto?"
                </button>
                <button
                  type="button"
                  onClick={() => handleSendClientMessage("Consigo pagar no Pix parcelado? Meu cartão não está passando")}
                  disabled={sendingMessage}
                  className="text-[10px] bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 px-2.5 py-1.5 rounded-lg font-medium transition-colors cursor-pointer"
                  title="Objeção 2: 'Pix Parcelado' - Alternativas de gateways"
                >
                  💳 "Consigo parcelar no Pix?"
                </button>
                <button
                  type="button"
                  onClick={() => handleSendClientMessage("Gostei muito. Me manda o link de pagamento atualizado para eu concluir agora")}
                  disabled={sendingMessage}
                  className="text-[10px] bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 px-2.5 py-1.5 rounded-lg font-medium transition-colors cursor-pointer"
                  title="Aprovação 3: 'Link' - Pedidos diretos de faturamento"
                >
                  🚀 "Manda o link pra pagar"
                </button>
              </div>
            </div>
          )}

          {/* Input messaging field */}
          <div className="p-4 bg-slate-900 border-t border-slate-950 flex items-center" id="chat-input-controls">
            <input
              type="text"
              value={clientMessage}
              onChange={(e) => setClientMessage(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !sendingMessage) handleSendClientMessage();
              }}
              disabled={!selectedLead || sendingMessage}
              placeholder={selectedLead ? "Escreva como cliente..." : "Selecione um lead acima para habilitar o chat..."}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 transition-all font-sans"
              id="chat-input-field"
            />
            <button
              onClick={() => handleSendClientMessage()}
              disabled={!selectedLead || !clientMessage.trim() || sendingMessage}
              className="ml-3.5 w-11 h-11 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:bg-slate-950 text-white flex items-center justify-center transition-all shadow-md shadow-indigo-600/10 cursor-pointer"
              id="send-chat-message-btn"
            >
              {sendingMessage ? (
                <RefreshCw className="w-4 h-4 animate-spin text-indigo-300" />
              ) : (
                <Send className="w-4 h-4 text-white" />
              )}
            </button>
          </div>
        </section>

        {/* Right Column (Architecture Logic Details & Real-Time Monitor Webhooks Feed) */}
        <section className="xl:col-span-3 flex flex-col space-y-5" id="right-logs-column">
          
          {/* Active Lead Metrics Insights */}
          {selectedLead && (
            <div className="bg-slate-900/60 border border-slate-900 rounded-2xl overflow-hidden shadow-xl" id="insights-lead-card">
              <div className="px-5 py-4 border-b border-slate-900 bg-slate-900/30 flex items-center justify-between" id="insights-header">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center">
                  <Eye className="w-4 h-4 text-emerald-400 mr-2" />
                  Métricas de Conversão
                </span>
                <span className="text-[10px] font-mono font-bold text-slate-500">INSIGHTS</span>
              </div>
              <div className="p-5 space-y-4" id="insights-lead-body">
                <div className="grid grid-cols-2 gap-3" id="state-counters">
                  <div className="bg-slate-950/60 border border-slate-900 rounded-xl p-3 text-center">
                    <span className="text-[9px] uppercase font-bold text-slate-500 tracking-wider">Interações</span>
                    <p className="text-lg font-bold font-mono text-white mt-1">{selectedLead.interactionsCount} / 3</p>
                    <span className="text-[8px] text-slate-500 block mt-0.5">mensagens do cliente</span>
                  </div>
                  <div className="bg-slate-950/60 border border-slate-900 rounded-xl p-3 text-center">
                    <span className="text-[9px] uppercase font-bold text-slate-500 tracking-wider">Desconto 10%</span>
                    <div className="mt-1 flex items-center justify-center space-x-1">
                      {selectedLead.couponOffered ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span className="text-xs font-bold font-mono text-emerald-400">ATIVADO</span>
                        </>
                      ) : (
                        <>
                          <AlertCircle className="w-4 h-4 text-slate-600 shrink-0" />
                          <span className="text-xs font-bold font-mono text-slate-400">BLOQUEADO</span>
                        </>
                      )}
                    </div>
                    <span className="text-[8px] text-slate-500 block mt-0.5">liberação p/ preço</span>
                  </div>
                </div>

                {selectedLead.couponOffered && selectedLead.couponCode && (
                  <div className="bg-emerald-950/20 border border-emerald-900/40 p-3.5 rounded-xl space-y-2 text-xs" id="discount-unlocked-card">
                    <div className="flex items-center space-x-2 text-emerald-400 font-semibold uppercase tracking-wider text-[10px]">
                      <Ticket className="w-4 h-4" />
                      <span>Cupom Gerado Dinamicamente!</span>
                    </div>
                    <div className="flex items-center justify-between bg-slate-950 border border-slate-800 p-2 rounded-lg font-mono">
                      <span className="text-slate-300 font-bold">{selectedLead.couponCode}</span>
                      <span className="text-[10px] text-emerald-400 bg-emerald-950 border border-emerald-900 px-1.5 py-0.5 rounded font-bold font-sans">
                        10% OFF
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 leading-normal">
                      Voucher ativo no gateway simulação. Novo valor reajustado pra R$ <strong className="text-slate-100 italic">{(selectedLead.price * 0.9).toFixed(2)}</strong>. Link prioritário enviado.
                    </p>
                  </div>
                )}

                <div className="bg-slate-950/60 border border-slate-900/80 rounded-xl p-4 space-y-2.5 text-xs text-slate-300" id="detailed-behavior-insights">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">Diagnóstico de Decisão da IA:</span>
                  <div className="space-y-2 text-slate-400 leading-relaxed font-sans text-xs">
                    <p>
                      <strong>Fase Técnica:</strong> {selectedLead.status === "aguardando" ? "Primeira tentativa ativa enviada de forma automática" : "Negociação ativa sob contorno de dores e preços."}
                    </p>
                    <p>
                      <strong>Gatilho atual:</strong> <span className="text-slate-300 font-medium">{selectedLead.gatilhoPsicologico}</span>
                    </p>
                    <p>
                      <strong>Estratégia Recomendada:</strong> {
                        selectedLead.eventType === "card_declined" 
                          ? "Focar em erro do banco ou transação recusada do gateway. Agilidade máxima é crítica." 
                          : selectedLead.eventType === "abandoned_checkout"
                          ? "Suporte pragmático. Entender se houve dúvidas ou problemas técnicos com o formulário."
                          : "Garantir a vaga e oferecer facilidade Pix rápido antes de fechar a turma."
                      }
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Activity feed logs */}
          <div className="bg-slate-900/60 border border-slate-900 rounded-2xl flex-1 flex flex-col overflow-hidden max-h-[350px] xl:max-h-none" id="activity-feed-wrapper">
            <div className="px-5 py-4 border-b border-slate-900 bg-slate-900/30 flex justify-between items-center" id="feed-header">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center">
                <Activity className="w-4 h-4 text-emerald-400 mr-2 animate-pulse" />
                Webhook Monitor & Logs
              </span>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3 font-mono" id="feed-content-scrollable">
              {logs.length === 0 ? (
                <div className="text-center text-xs text-slate-600 py-12 select-none">
                  Nenhuma atividade registrada na fila técnica.
                </div>
              ) : (
                logs.map((log) => {
                  let badgeIcon = <Plus className="w-3 h-3 text-indigo-400" />;
                  let bgBg = "bg-slate-950 border-slate-900";
                  
                  if (log.type === "chat_message") {
                    badgeIcon = <MessageSquare className="w-3 h-3 text-amber-400" />;
                    bgBg = "bg-slate-950/85 border-slate-900/60";
                  } else if (log.type === "sale_recovered") {
                    badgeIcon = <CheckCircle2 className="w-3 h-3 text-emerald-400" />;
                    bgBg = "border-emerald-900/30 bg-emerald-950/10";
                  } else if (log.type === "sale_lost") {
                    badgeIcon = <XCircle className="w-3 h-3 text-rose-500" />;
                    bgBg = "border-rose-950/30 bg-rose-950/5";
                  }

                  return (
                    <div key={log.id} className={`p-3 border rounded-lg text-[10px] space-y-1.5 leading-relaxed text-left ${bgBg}`}>
                      <div className="flex items-center justify-between text-slate-500 border-b border-slate-900 pb-1" id="log-meta">
                        <span className="flex items-center space-x-1.5">
                          {badgeIcon}
                          <span className="font-semibold text-slate-400 uppercase tracking-wider">
                            {log.type === "webhook_received" ? "Webhook" : log.type === "chat_message" ? "Mensagem" : "Conclusão"}
                          </span>
                        </span>
                        <span>
                          {new Date(log.timestamp).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                        </span>
                      </div>
                      <p className="text-slate-300 leading-normal">{log.message}</p>
                      {log.leadId && (
                        <div className="text-[9px] text-indigo-400 flex items-center justify-end font-sans">
                          ver lead <ChevronRight className="w-2.5 h-2.5 ml-0.5" />
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </section>

      </div>

      {/* Aesthetic Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 px-6 text-center text-xs text-slate-500 font-mono" id="applet-footer">
        <p>NordicROI Engine v2.4 — Designed for Premium SaaS Recovery Conversions</p>
      </footer>
    </div>
  );
}
