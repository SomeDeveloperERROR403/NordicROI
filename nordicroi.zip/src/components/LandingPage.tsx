import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  MessageSquare,
  Sparkles,
  TrendingUp,
  CheckCircle2,
  Lock,
  Smartphone,
  Layers,
  Zap,
  Ticket,
  Percent,
  Coins,
  ArrowRight,
  ShieldCheck,
  Chrome,
  ChevronRight,
  Menu,
  X,
  Play
} from "lucide-react";

interface LandingPageProps {
  onLoginSuccess: (user: { name: string; email: string; avatar: string }) => void;
}

export default function LandingPage({ onLoginSuccess }: LandingPageProps) {
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginStep, setLoginStep] = useState<"initial" | "loading" | "success">("initial");
  const [selectedAccount, setSelectedAccount] = useState<string>("");
  const [customEmail, setCustomEmail] = useState("");
  const [customName, setCustomName] = useState("");
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [pwaInstalled, setPWAInstalled] = useState(false);
  const [showPwaGuide, setShowPwaGuide] = useState(false);

  // Active interaction preview state
  const [previewScenario, setPreviewScenario] = useState<"fraude" | "saldo" | "boleto">("saldo");
  const [showPreviewSuccess, setShowPreviewSuccess] = useState(false);

  // Catch PWA beforeinstallprompt
  useEffect(() => {
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener("beforeinstallprompt", handleBeforeInstall);

    const handleAppInstalled = () => {
      setPWAInstalled(true);
      setDeferredPrompt(null);
    };
    window.addEventListener("appinstalled", handleAppInstalled);

    // Check if running in standalone mode already
    if (window.matchMedia("(display-mode: standalone)").matches) {
      setPWAInstalled(true);
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstall);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, []);

  const triggerPWAInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        setPWAInstalled(true);
      }
      setDeferredPrompt(null);
    } else {
      setShowPwaGuide(true);
    }
  };

  const handleGoogleLogin = (accountType: "emerson" | "custom") => {
    setLoginStep("loading");
    let name = "Emerson Aiuruoca";
    let email = "emersonaiuruoca2018@gmail.com";

    if (accountType === "custom" && customEmail.trim()) {
      email = customEmail;
      name = customName.trim() || customEmail.split("@")[0];
    }

    setSelectedAccount(email);

    // Dynamic timeout to simulate safe authentication state
    setTimeout(() => {
      setLoginStep("success");
      setTimeout(() => {
        onLoginSuccess({
          name,
          email,
          avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name)}`
        });
      }, 800);
    }, 1800);
  };

  // Preset scenarios to showcase how NordicROI works
  const scenarios = {
    fraude: {
      type: "Bloqueio Antifraude Suspeito",
      desc: "Cartão rejeitado pela operadora duas vezes.",
      lead: "Carlos Eduardo Mendes",
      failPrice: "R$ 147,00",
      aiMessage: "Oi Carlos, tudo bem? Vi aqui que a operadora recusou o pagamento do InboundGrow AI. Quer utilizar Pix ou boleto com liberação imediata sem passar pelo sistema de score?",
      clientReply: "Caramba, eu achei que era o meu cartão! Se for no Pix eu consigo fechar agora, você tem link?",
      recoveryStatus: "Pago via Pix com 10% de conversão",
      delay: "Envio instantâneo (2 min)"
    },
    saldo: {
      type: "Saldo Insuficiente",
      desc: "Cartão recusado pelo emissor (erro genérico 51).",
      lead: "Sarah Martins da Silva",
      failPrice: "R$ 297,00",
      aiMessage: "Oi Sarah, compreendo que o limite bancário às vezes complica o mês! Consegui uma liberação especial para você parcelar o CloudPulse Metrics no Pix em 2x sem juros. Gostaria de ativar?",
      clientReply: "Perfeito! Em 2 vezes no Pix cabe certinho no orçamento. Mande a primeira chave pfv!",
      recoveryStatus: "Venda Recuperada: Entrada de R$ 148,50 confirmada",
      delay: "Envio calibrado (15 min)"
    },
    boleto: {
      type: "Boleto Expirado",
      desc: "Boleto não pago gerado há 3 dias no gateway.",
      lead: "Vitor Rezende Albuquerque",
      failPrice: "R$ 349,00",
      aiMessage: "Oi Vitor! O e-mail automático avisou que o cupom exclusivo expira hoje. Que tal pagar por Pix hoje e ganhar o onboarding estratégico de graça para poupar o tempo de faturamento?",
      clientReply: "Muito bom, vou pagar agora por aqui no Pix para não perder esse onboarding!",
      recoveryStatus: "Faturamento Salvo: Compra confirmada",
      delay: "Programado (60 min)"
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col overflow-x-hidden selection:bg-indigo-500 selection:text-white" id="landing-container">
      {/* Decorative Glow Elements */}
      <div className="absolute top-[-10%] left-[-20%] w-[600px] h-[600px] rounded-full bg-indigo-900/10 blur-[150px] pointer-events-none" />
      <div className="absolute top-[20%] right-[-10%] w-[500px] h-[500px] rounded-full bg-emerald-900/10 blur-[130px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[10%] w-[700px] h-[700px] rounded-full bg-slate-900/40 blur-[170px] pointer-events-none" />

      {/* Modern Header Nav */}
      <header className="border-b border-slate-900/80 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40 py-4 px-6 md:px-12 flex items-center justify-between" id="landing-header">
        <div className="flex items-center space-x-3" id="landing-logo">
          <div className="w-9 h-9 rounded-xl overflow-hidden border border-slate-800 bg-slate-950 flex items-center justify-center p-0.5 shadow-md shadow-indigo-500/10">
            <img
              src="/nordicroi-logo.png"
              alt="NordicROI Logo"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <h1 className="text-base font-bold tracking-tight text-white flex items-center">
              NordicROI
              <span className="ml-2 text-[8px] tracking-widest text-emerald-400 font-mono bg-emerald-950 border border-emerald-900 px-1 rounded uppercase">
                PWA Active
              </span>
            </h1>
          </div>
        </div>

        <nav className="hidden md:flex items-center space-x-8 text-xs text-slate-400 font-medium">
          <a href="#diferenciais" className="hover:text-slate-100 transition-colors">Diferenciais</a>
          <a href="#como-funciona" className="hover:text-slate-100 transition-colors">Como Funciona</a>
          <a href="#pwa" className="hover:text-slate-100 transition-colors">Benefícios PWA</a>
          <a href="#simulador" className="hover:text-slate-100 transition-colors">Tecnologia</a>
        </nav>

        <div className="flex items-center space-x-3" id="header-ctas">
          {!pwaInstalled && (
            <button
              onClick={triggerPWAInstall}
              className="hidden lg:flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 transition-all hover:border-slate-700"
            >
              <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
              <span>Instalar Aplicativo</span>
            </button>
          )}
          <button
            onClick={() => {
              setLoginStep("initial");
              setShowLoginModal(true);
            }}
            className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-4 py-2 rounded-xl transition-all shadow-lg hover:shadow-indigo-500/20 active:scale-95 duration-150 cursor-pointer"
            id="login-trigger-btn"
          >
            <span>Minha Conta (Google)</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1" id="landing-main">
        {/* HERO SECTION */}
        <section className="relative px-6 md:px-12 pt-16 pb-20 max-w-7xl mx-auto flex flex-col lg:grid lg:grid-cols-12 gap-12 items-center" id="hero">
          <div className="lg:col-span-7 space-y-6 text-left" id="hero-text-block">
            {/* Active Live Badge */}
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-indigo-950/40 border border-indigo-900/60 rounded-full text-indigo-400 text-[10px] font-bold tracking-wide uppercase">
              <Sparkles className="w-3 h-3 text-indigo-400 animate-pulse" />
              <span>O canhão de recuperação ideal para o seu SaaS</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-5xl font-black tracking-tight leading-tight text-white">
              Recupere até <span className="text-indigo-400 bg-clip-text">42% dos checkouts recusados</span> em piloto automático via WhatsApp.
            </h1>

            <p className="text-sm sm:text-base text-slate-400 leading-relaxed font-sans max-w-2xl">
              Nossa engine inteligente se conecta aos webhooks dos seus gateways favoritos (Kiwify, Hotmart, Appmax) e inicia uma conversa humanizada em tempo de delay milimétrico, contornando falhas de limite, boleto vencido ou falsas suspeitas de fraude.
            </p>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-4 pt-3" id="hero-actions">
              <button
                onClick={() => {
                  setLoginStep("initial");
                  setShowLoginModal(true);
                }}
                className="flex items-center justify-center space-x-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-sm px-6 py-3.5 rounded-xl transition-all shadow-xl shadow-indigo-500/20 active:scale-95 duration-150 cursor-pointer"
              >
                <img
                  src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
                  alt="Google G logo"
                  className="w-4 h-4"
                />
                <span>Entrar Grátis com o Google</span>
              </button>

              <button
                onClick={triggerPWAInstall}
                className="flex items-center justify-center space-x-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-300 font-semibold text-xs px-5 py-3.5 rounded-xl transition-all"
              >
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span>{pwaInstalled ? "Aplicativo Instalado ✅" : "Instalar como Aplicativo (PWA)"}</span>
              </button>
            </div>

            {/* Quick Metrics stats Row */}
            <div className="grid grid-cols-3 gap-4 pt-8 border-t border-slate-900/60 max-w-lg" id="quick-stats">
              <div>
                <p className="text-2xl font-bold font-mono text-white">42%</p>
                <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Recuperação Máxima</p>
              </div>
              <div>
                <p className="text-2xl font-bold font-mono text-emerald-400">&lt; 3s</p>
                <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Detecção pelo Webhook</p>
              </div>
              <div>
                <p className="text-2xl font-bold font-mono text-indigo-400">100%</p>
                <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">PWA & Nuvem</p>
              </div>
            </div>
          </div>

          {/* Interactive Screen Layout Mockup */}
          <div className="lg:col-span-12 xl:col-span-5 w-full flex justify-center" id="hero-mockup-block">
            <div className="w-full max-w-md bg-slate-900/60 border border-slate-900 rounded-2xl overflow-hidden shadow-2xl relative" id="live-preview-widget">
              <div className="absolute top-0 right-0 w-[200px] h-[200px] rounded-full bg-indigo-500/5 blur-[50px] pointer-events-none" />
              
              <div className="bg-slate-950/90 border-b border-slate-900 p-4 flex items-center justify-between" id="sim-widget-header">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                  <span className="text-[10px] font-bold font-mono text-rose-500 uppercase tracking-widest">
                    Falha Detectada no Gateway
                  </span>
                </div>
                <div className="flex space-x-1">
                  <span className="text-[9px] font-mono text-slate-500 bg-slate-950 px-2 py-0.5 rounded border border-slate-900">
                    Kiwify Webhook
                  </span>
                </div>
              </div>

              {/* Scenario selector tabs */}
              <div className="grid grid-cols-3 border-b border-slate-900 bg-slate-950/40 text-[10px] font-semibold text-slate-500 text-center" id="sim-tabs">
                <button
                  type="button"
                  onClick={() => setPreviewScenario("saldo")}
                  className={`py-2 border-r border-slate-900 transition-colors uppercase tracking-wider ${
                    previewScenario === "saldo" ? "text-indigo-400 bg-slate-950/80 font-bold border-b-2 border-b-indigo-500" : "hover:text-slate-300"
                  }`}
                >
                  Saldo Insuficiente
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewScenario("fraude")}
                  className={`py-2 border-r border-slate-900 transition-colors uppercase tracking-wider ${
                    previewScenario === "fraude" ? "text-rose-400 bg-slate-950/80 font-bold border-b-2 border-b-rose-500" : "hover:text-slate-300"
                  }`}
                >
                  Erro Antifraude
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewScenario("boleto")}
                  className={`py-2 transition-colors uppercase tracking-wider ${
                    previewScenario === "boleto" ? "text-amber-400 bg-slate-950/80 font-bold border-b-2 border-b-amber-500" : "hover:text-slate-300"
                  }`}
                >
                  Boleto Vencido
                </button>
              </div>

              {/* Chat Simulation Sandbox */}
              <div className="p-4 space-y-4" id="sim-sandbox-content">
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono">
                    <span>CLIENTE: {scenarios[previewScenario].lead}</span>
                    <span className="text-slate-400 font-semibold">{scenarios[previewScenario].failPrice}</span>
                  </div>
                  <div className="bg-slate-950 border border-slate-910 p-2.5 rounded-lg text-xs flex justify-between items-center text-slate-400">
                    <span>Objeção: <strong className="text-slate-300">{scenarios[previewScenario].type}</strong></span>
                    <span className="text-[9px] text-slate-500 italic">{scenarios[previewScenario].desc}</span>
                  </div>
                </div>

                {/* Simulated Conversation Bubble */}
                <div className="space-y-3" id="sim-bubbles">
                  {/* System/Agent bubble */}
                  <div className="flex items-start space-x-2.5 select-none animate-fade-in" key={`agent-${previewScenario}`}>
                    <div className="w-7 h-7 rounded-lg bg-indigo-950 border border-indigo-900/50 flex items-center justify-center shrink-0">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                    </div>
                    <div className="bg-indigo-950/50 border border-indigo-900/20 text-indigo-100 p-3 rounded-xl rounded-tl-none leading-relaxed text-xs text-left max-w-[85%]">
                      <div className="flex items-center space-x-1.5 mb-1">
                        <span className="text-[9px] font-bold text-indigo-400 uppercase tracking-wide">NordicROI IA</span>
                        <span className="text-[8px] text-slate-500 font-mono">• {scenarios[previewScenario].delay}</span>
                      </div>
                      <p className="text-slate-200">{scenarios[previewScenario].aiMessage}</p>
                    </div>
                  </div>

                  {/* Customer bubble */}
                  <div className="flex items-start space-x-2.5 justify-end" key={`customer-${previewScenario}`}>
                    <div className="bg-slate-950 border border-slate-800 text-slate-100 p-3 rounded-xl rounded-tr-none leading-relaxed text-xs text-left max-w-[85%]">
                      <div className="flex items-center space-x-1.5 mb-1.5">
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wide">{scenarios[previewScenario].lead.split(" ")[0]} (Cliente)</span>
                        <span className="text-[8px] text-emerald-400 font-mono bg-emerald-950 px-1 py-0.2 rounded border border-emerald-900">Online</span>
                      </div>
                      <p className="text-slate-300 italic">"{scenarios[previewScenario].clientReply}"</p>
                    </div>
                    <div className="w-7 h-7 rounded-lg bg-slate-850 border border-slate-800 flex items-center justify-center shrink-0">
                      <div className="w-4 h-4 rounded-full bg-slate-700 text-[8px] font-bold text-white flex items-center justify-center">
                        {scenarios[previewScenario].lead.slice(0, 1)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Successful recovery indicator banner */}
                <div className="bg-emerald-950/20 border border-emerald-900/30 p-3 rounded-xl flex items-center justify-between" id="sim-banner">
                  <div className="flex items-center space-x-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                    <div className="text-left">
                      <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">Resultado</p>
                      <p className="text-xs font-semibold text-slate-200">{scenarios[previewScenario].recoveryStatus}</p>
                    </div>
                  </div>
                  <span className="text-[9px] font-mono text-emerald-500 font-bold bg-emerald-950/60 border border-emerald-900/40 px-2 py-0.5 rounded">
                    + R$ Lançado
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FEATURES BENTO GRID */}
        <section className="bg-slate-900/30 border-y border-slate-900 relative py-20 px-6 md:px-12" id="diferenciais">
          <div className="max-w-7xl mx-auto space-y-12">
            <div className="text-center max-w-2xl mx-auto space-y-3">
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-indigo-400">BENEFÍCIOS ELITE</span>
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Por que as maiores Micro-SaaS confiam no NordicROI?</h2>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed font-sans">
                Nós transformamos eventos frios de webhooks de faturamento em fluxos quentes de conversão usando inteligência psicológica baseada em dados reais de checkout.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="bento-grid-landing">
              {/* Box 1 */}
              <div className="bg-slate-900/50 hover:bg-slate-900/80 transition-all border border-slate-900 p-6 rounded-2xl flex flex-col justify-between group" id="bento-item-1">
                <div className="w-10 h-10 rounded-xl bg-indigo-950 text-indigo-400 border border-indigo-900/40 flex items-center justify-center mb-6">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <h3 className="text-base font-bold text-white group-hover:text-indigo-400 transition-colors">Taxas Máximas de Conversão</h3>
                  <p className="text-xs text-slate-400 font-sans mt-2 leading-relaxed">
                    Não gaste dinheiro enviando ofertas frias para quem não quer comprar. Identifique a dor específica (falta de crédito para pagar o ano todo, cartão bloqueado preventivo ou boleto esquecido) e dispare o gatilho perfeito.
                  </p>
                </div>
              </div>

              {/* Box 2 */}
              <div className="bg-slate-900/50 hover:bg-slate-900/80 transition-all border border-slate-900 p-6 rounded-2xl flex flex-col justify-between group" id="bento-item-2">
                <div className="w-10 h-10 rounded-xl bg-rose-950/40 text-rose-400 border border-rose-900/30 flex items-center justify-center mb-6">
                  <Zap className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <h3 className="text-base font-bold text-white group-hover:text-rose-400 transition-colors">Webhooks de Integração Instantâneos</h3>
                  <p className="text-xs text-slate-400 font-sans mt-2 leading-relaxed">
                    Receba e processe webhooks de faturamento em milissegundos. Esqueça infraestruturas lentas ou cronjobs pesados. Toda falha reportada no carrinho simula automaticamente seu encaminhamento na fila de inteligência.
                  </p>
                </div>
              </div>

              {/* Box 3 */}
              <div className="bg-slate-900/50 hover:bg-slate-900/80 transition-all border border-slate-900 p-6 rounded-2xl flex flex-col justify-between group" id="bento-item-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-950/40 text-emerald-400 border border-emerald-900/30 flex items-center justify-center mb-6">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <h3 className="text-base font-bold text-white group-hover:text-emerald-400 transition-colors">Preparado para PWA Autônomo</h3>
                  <p className="text-xs text-slate-400 font-sans mt-2 leading-relaxed">
                    Funciona como um aplicativo nativo em qualquer sistema operacional (inclusive no seu iPhone ou Android!). Suporta atalhos exclusivos, widgets de acompanhamento de caixa e atualizações offline em background.
                  </p>
                </div>
              </div>

              {/* Box 4 */}
              <div className="bg-slate-900/50 hover:bg-slate-900/80 transition-all border border-slate-900 p-6 rounded-2xl flex flex-col justify-between group" id="bento-item-4">
                <div className="w-10 h-10 rounded-xl bg-amber-950/40 text-amber-400 border border-amber-900/30 flex items-center justify-center mb-6">
                  <Layers className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <h3 className="text-base font-bold text-white group-hover:text-amber-400 transition-colors">Diagnóstico Comportamental</h3>
                  <p className="text-xs text-slate-400 font-sans mt-2 leading-relaxed">
                    Analise quantas vezes o usuário clicou na página de preços nos últimos 7 dias, se baixou materiais de nutrição, ou se já configurou uma conta sandbox na plataforma para construir um contexto de ajuda imbatível.
                  </p>
                </div>
              </div>

              {/* Box 5 */}
              <div className="bg-slate-900/50 hover:bg-slate-900/80 transition-all border border-slate-900 p-6 rounded-2xl flex flex-col justify-between group" id="bento-item-5">
                <div className="w-10 h-10 rounded-xl bg-indigo-950/50 text-indigo-400 border border-indigo-900/40 flex items-center justify-center mb-6">
                  <Lock className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <h3 className="text-base font-bold text-white group-hover:text-indigo-400 transition-colors">Segurança & IA</h3>
                  <p className="text-xs text-slate-400 font-sans mt-2 leading-relaxed">
                    Cofre criptografado de chaves e conformidade LGPD ativa. Todos os dados enviados pelos clientes de simulação permanecem no seu navegador e em cache local, prevenindo vazamentos de carteiras confidenciais.
                  </p>
                </div>
              </div>

              {/* Box 6: Interactive Call action */}
              <div className="bg-gradient-to-br from-indigo-950/40 to-slate-900/80 border border-indigo-900/40 p-6 rounded-2xl flex flex-col justify-between group" id="bento-item-6">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center mb-6">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <h3 className="text-base font-bold text-white">Prontificado para Iniciar</h3>
                  <p className="text-xs text-slate-400 font-sans mt-1.5 leading-relaxed">
                    Acelere o recebimento de leads da sua empresa hoje mesmo! Faça o login direto do Google e acerte as configurações de checkout para seu produto.
                  </p>
                  <button
                    onClick={() => {
                      setLoginStep("initial");
                      setShowLoginModal(true);
                    }}
                    className="mt-4 flex items-center space-x-1.5 text-xs text-indigo-400 font-bold hover:text-indigo-300 transition-colors"
                  >
                    <span>Começar Agora Gratuitamente</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* PWA INTEGRATION DETAILS */}
        <section className="py-20 px-6 md:px-12 max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center" id="como-funciona">
          <div className="lg:col-span-5 w-full flex justify-center order-2 lg:order-1" id="pwa-advantages-visual">
            <div className="w-full max-w-sm bg-slate-900/40 border border-slate-900/80 p-6 rounded-2xl relative space-y-4" id="pwa-benefits-card">
              <div className="absolute top-3 right-4 flex items-center space-x-1 bg-emerald-950 border border-emerald-900/60 text-emerald-400 font-mono text-[8px] px-2 py-0.5 rounded-full font-bold">
                <Chrome className="w-2.5 h-2.5" />
                <span>PWA DE ALTO RENDIMENTO</span>
              </div>

              <div className="space-y-1 text-left">
                <h4 className="text-sm font-bold text-white">NordicROI — Aplicativo PWA</h4>
                <p className="text-[11px] text-slate-500 font-sans">Desenvolvido em conformidade para instalação offline</p>
              </div>

              <div className="space-y-2.5 font-sans" id="pwa-check-lines">
                <div className="flex items-start space-x-3 text-xs leading-normal">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-200">Instalação One-Click:</strong>
                    <p className="text-[11px] text-slate-400">Instale direto no celular ou desktop sem precisar buscar na loja oficial.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3 text-xs leading-normal">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-200">Atalhos Personalizados:</strong>
                    <p className="text-[11px] text-slate-400">Envie leads de simulação no atalho rápido sem abrir a aba do navegador.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3 text-xs leading-normal">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-200">Visualização de Widget Lateral:</strong>
                    <p className="text-[11px] text-slate-400">Disponibiliza status de faturamento diário resumido na área de trabalho do OS.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3 text-xs leading-normal">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-200">Resiliência de Rede:</strong>
                    <p className="text-[11px] text-slate-400">Mantenha a triagem aberta mesmo com internet instável usando cache local do Service Worker.</p>
                  </div>
                </div>
              </div>

              <button
                onClick={triggerPWAInstall}
                className="w-full py-2.5 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 transition-colors shadow-md shadow-indigo-600/10 cursor-pointer"
              >
                Instalar NordicROI no Dispositivo
              </button>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-6 text-left order-1 lg:order-2" id="pwa-details-block">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-400">DESKTOP & MOBILE INTEGRATION</span>
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
              Nenhum aplicativo na loja te entrega o conforto de um PWA.
            </h2>
            <p className="text-sm font-sans text-slate-400 leading-relaxed">
              Trabalhar com a recuperação de checkouts exige agilidade extrema ao carregar dados. Graças ao nosso design exclusivo voltado para PWA, você pode acessar e gerenciar o NordicROI como um aplicativo nativo no seu Windows, Android, macOS ou iOS.
            </p>

            <div className="space-y-3.5" id="pwa-tech-highlights">
              <div className="p-4 rounded-xl bg-slate-900/30 border border-slate-900/70" id="tech-highlight-1">
                <p className="text-xs font-semibold text-white">Completamente Livre de Lojas</p>
                <p className="text-[11px] text-slate-400 mt-1 font-sans">
                  Não sofra com atualizações pesadas da App Store ou Google Play. Sempre que entrar no NordicROI, você usará a versão mais otimizada instantaneamente.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/30 border border-slate-900/70" id="tech-highlight-2">
                <p className="text-xs font-semibold text-white">Consumo Minúsculo de Recursos</p>
                <p className="text-[11px] text-slate-400 mt-1 font-sans">
                  Nosso Service Worker armazena apenas o essencial para indexação rápida, liberando espaço no seu armazenamento e garantindo carregamentos fluidos em qualquer celular modesto.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="border-t border-slate-950 bg-slate-950 py-8 px-6 text-center text-xs text-slate-500 font-sans" id="landing-footer">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <div className="w-5 h-5 rounded overflow-hidden p-0.5 border border-slate-800 bg-slate-900">
              <img src="/nordicroi-logo.png" alt="Logo mini" className="w-full h-full object-cover" />
            </div>
            <span className="font-bold text-slate-400">NordicROI</span>
          </div>
          <p className="text-[11px] text-slate-600 font-mono">
            NordicROI Engine v2.4 — Designed for Premium SaaS Recovery Conversions PWA.
          </p>
          <div className="flex space-x-4 text-[11px]">
            <a href="#" className="hover:underline">PWA Manifest</a>
            <a href="#" className="hover:underline">Suporte Corporativo</a>
          </div>
        </div>
      </footer>

      {/* GOOGLE SIGN IN MODAL / POPUP SIMULATOR */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4" id="google-login-modal">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-850 rounded-2xl shadow-2xl overflow-hidden relative" id="google-dialog-card">
            
            {/* Modal close icon */}
            {loginStep !== "loading" && (
              <button
                onClick={() => setShowLoginModal(false)}
                className="absolute top-4 right-4 text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
                title="Fechar"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            {loginStep === "initial" && (
              <div className="p-6 space-y-5" id="google-pane-initial">
                <div className="text-center space-y-1">
                  {/* Google Custom G Logo */}
                  <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white shadow p-2 mb-2">
                    <img
                      src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
                      alt="Google logo"
                      className="w-full h-full"
                    />
                  </div>
                  <h3 className="text-sm font-bold text-white">Fazer login com o Google</h3>
                  <p className="text-[11px] text-slate-400">para continuar no aplicativo <strong className="text-indigo-400">NordicROI</strong></p>
                </div>

                <div className="space-y-2" id="available-accounts-list">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block text-left">Escolha uma Conta:</span>
                  
                  {/* Emerson simulated account from metadata */}
                  <button
                    onClick={() => handleGoogleLogin("emerson")}
                    className="w-full p-3 rounded-xl border border-slate-800 bg-slate-950/50 hover:bg-slate-950 hover:border-slate-700 transition-all flex items-center space-x-3 text-left focus:outline-none"
                    id="account-btn-emerson"
                  >
                    <div className="w-7 h-7 rounded-full bg-indigo-950 border border-indigo-900 text-[10px] font-bold text-white flex items-center justify-center overflow-hidden">
                      <img
                        src="https://api.dicebear.com/7.x/initials/svg?seed=Emerson"
                        alt="Emerson avatar"
                        className="w-full h-full"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-slate-200">Emerson Aiuruoca</p>
                      <p className="text-[10px] text-slate-400 truncate">emersonaiuruoca2018@gmail.com</p>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                  </button>

                  <div className="border-t border-slate-800/60 my-3" />

                  {/* Manual Sign-in simulated block */}
                  <div className="space-y-2 bg-slate-950/20 border border-slate-800/80 p-3 rounded-xl text-left" id="custom-account-holder">
                    <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Usar outro e-mail:</p>
                    <div className="space-y-1.5">
                      <input
                        type="email"
                        value={customEmail}
                        onChange={(e) => setCustomEmail(e.target.value)}
                        placeholder="nome@exemplo.com"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500 transition-all font-sans"
                      />
                      <input
                        type="text"
                        value={customName}
                        onChange={(e) => setCustomName(e.target.value)}
                        placeholder="Seu Nome Completo"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500 transition-all font-sans"
                      />
                      <button
                        onClick={() => handleGoogleLogin("custom")}
                        disabled={!customEmail.trim()}
                        className="w-full py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-all disabled:opacity-40 disabled:pointer-events-none mt-1"
                      >
                        Autenticar Conta Customizada
                      </button>
                    </div>
                  </div>
                </div>

                <p className="text-[10px] text-slate-500 text-center leading-normal">
                  Para proteger seus dados, o NordicROI usa logins simulados seguros baseados no sandbox experimental do Google AI Studio para testes offline.
                </p>
              </div>
            )}

            {loginStep === "loading" && (
              <div className="p-8 text-center space-y-4" id="google-pane-loading">
                <div className="w-12 h-12 rounded-full border-4 border-slate-800 border-t-indigo-500 animate-spin mx-auto" />
                <div className="space-y-1.5">
                  <p className="text-xs font-bold text-white uppercase tracking-wider">Negociando Credenciais...</p>
                  <p className="text-[10px] text-slate-500 font-mono">Conectando ao Google OAuth API</p>
                </div>
                <div className="p-3 bg-slate-950 border border-slate-900 rounded-xl text-[10px] text-indigo-400 font-mono text-left space-y-1">
                  <p className="text-slate-500">&gt; GET /oauth/v2/auth...</p>
                  <p className="text-slate-500">&gt; Status: 200 OK</p>
                  <p>&gt; Conta: {selectedAccount}</p>
                  <p className="animate-pulse">&gt; Sincronizando NordicROI Session...</p>
                </div>
              </div>
            )}

            {loginStep === "success" && (
              <div className="p-8 text-center space-y-4" id="google-pane-success">
                <div className="w-12 h-12 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-900/60 flex items-center justify-center mx-auto text-xl font-bold animate-bounce shadow">
                  ✓
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-emerald-400 uppercase tracking-widest">Sincronização Concluída!</p>
                  <p className="text-xs text-slate-300">Acesso liberado de forma segura.</p>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* PWA GUIDE HELPER BOTTOM POPUP */}
      {showPwaGuide && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4" id="pwa-guide-modal">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 relative text-left space-y-4">
            <button
              onClick={() => setShowPwaGuide(false)}
              className="absolute top-4 right-4 text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center space-x-2 bg-indigo-950/50 border border-indigo-900/60 p-2.5 rounded-xl text-indigo-400">
              <Smartphone className="w-5 h-5" />
              <span className="text-xs font-bold uppercase tracking-wider">Como Instalar o NordicROI</span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed font-sans">
              Como seu navegador não disparou o prompt automático de instalação (ou você já os possui instalados), siga estas etapas simples de acordo com seu ambiente:
            </p>

            <div className="space-y-3 font-sans" id="pwa-steps-list">
              <div className="p-3 bg-slate-950 border border-slate-910 rounded-xl text-xs space-y-1">
                <span className="font-bold text-slate-200 flex items-center">
                  <span className="w-4 h-4 rounded-full bg-indigo-950 border border-indigo-900 text-[10px] text-indigo-400 font-bold inline-flex items-center justify-center mr-1.5">1</span>
                  No iPhone ou iPad (iOS)
                </span>
                <p className="text-[11px] text-slate-400 leading-relaxed pl-5">
                  Abra este app no <strong className="text-slate-100 font-semibold">Safari</strong>, clique no botão de <strong className="text-indigo-400">Compartilhar</strong> (ícone de seta pra cima) e selecione <strong className="text-slate-100 font-semibold">Adicionar à Tela de Início</strong>.
                </p>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-910 rounded-xl text-xs space-y-1">
                <span className="font-bold text-slate-200 flex items-center">
                  <span className="w-4 h-4 rounded-full bg-indigo-950 border border-indigo-900 text-[10px] text-indigo-400 font-bold inline-flex items-center justify-center mr-1.5">2</span>
                  No Android (Chrome)
                </span>
                <p className="text-[11px] text-slate-400 leading-relaxed pl-5">
                  Clique nos <strong className="text-slate-100 font-semibold">três pontinhos</strong> no canto superior direito do Chrome e selecione <strong className="text-indigo-400">Instalar Aplicativo</strong> ou <strong className="text-indigo-100">Adicionar à tela principal</strong>.
                </p>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-910 rounded-xl text-xs space-y-1">
                <span className="font-bold text-slate-200 flex items-center">
                  <span className="w-4 h-4 rounded-full bg-indigo-950 border border-indigo-900 text-[10px] text-indigo-400 font-bold inline-flex items-center justify-center mr-1.5">3</span>
                  No Computador (Chrome / Edge)
                </span>
                <p className="text-[11px] text-slate-400 leading-relaxed pl-5">
                  Verifique o ícone de <strong className="text-indigo-400">Computador com Setinha</strong> no canto direito da sua barra de endereços (URL) para instalar diretamente em sua área de trabalho.
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowPwaGuide(false)}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-200 font-semibold text-xs rounded-xl transition-colors cursor-pointer"
            >
              Compreendi
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
