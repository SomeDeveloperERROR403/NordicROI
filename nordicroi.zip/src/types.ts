export type EventType = "abandoned_checkout" | "card_declined" | "boleto_expired";
export type LeadStatus = "aguardando" | "negociando" | "convertido" | "perdido";
export type PriorityLevel = "alto" | "medio" | "baixo";

export interface ChatMessage {
  sender: "client" | "architect";
  message: string;
  timestamp: string;
}

export interface Lead {
  id: string;
  name: string;
  phone: string;
  productName: string;
  price: number;
  eventType: EventType;
  reason: string;
  priority: PriorityLevel;
  behaviorHistory: string;
  status: LeadStatus;
  whatsappMessage: string;
  delayEnvio: string;
  gatilhoPsicologico: string;
  interactionsCount: number;
  couponOffered: boolean;
  couponCode?: string;
  chatHistory: ChatMessage[];
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  type: "webhook_received" | "chat_message" | "sale_recovered" | "sale_lost";
  message: string;
  leadName: string;
  leadId: string;
}
